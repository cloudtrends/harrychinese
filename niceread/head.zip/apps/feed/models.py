# -*- coding: utf-8 -*-

import datetime
from markdown import markdown

from django.db import models
from django.contrib.auth.models import User
from tagging.fields import TagField
from tagging.models import Tag

class ReadFeed(models.Model):
    title = models.CharField(u'标题', max_length=255)
    creater = models.ForeignKey(User)
    url = models.URLField(u'源网址', null=True, blank=True)
    content = models.TextField(u'内容')
    content_html = models.TextField(u'内容', editable=False)
    tags = TagField(u'标签', blank=True)
    pub_date = models.DateTimeField(u'发布日期', editable=False)
    updated_date = models.DateTimeField('更新日期', editable=False)
    secret = models.BooleanField(u'私密', default=False)
    status = models.BooleanField(u'阅读状态', default=False)

    class Meta:
        ordering = ['-pub_date']

    def __unicode__(self):
        return self.title

    @models.permalink
    def get_absolute_url(self):
        return ('feed_detail', (), {
            'feed_pk': self.pk
            })

    def save(self, *args, **kwargs):
        if not self.pk:
            self.pub_date = datetime.datetime.now()
        self.updated_date = datetime.datetime.now()
        self.content_html = markdown(self.content)

        super(ReadFeed, self).save(*args, **kwargs)

    def _get_tags(self):
        return Tag.objects.get_for_object(self)

    def _set_tags(self, tags):
        return Tag.objects.update_tags(self, tags)

    obj_tags = property(_get_tags, _set_tags)

class Share(models.Model):
    feed = models.ForeignKey(ReadFeed)
    pub_date = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User)

    class Meta:
        ordering = ['-pub_date']

    def __unicode__(self):
        return self.feed.title

class Star(models.Model):
    feed = models.ForeignKey(ReadFeed)
    pub_date = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User)

    class Meta:
        ordering = ['-pub_date']

    def __unicode__(self):
        return self.feed.title

