# -*- coding: utf-8 -*-

from django import forms
from django.contrib.auth.models import User

from feed.models import ReadFeed

class ReadFeedForm(forms.ModelForm):
    class Meta:
        model = ReadFeed
        fields = ('title', 'url', 'content','tags', 'secret', )

    def save(self, user):
        title = self.cleaned_data['title']
        url = self.cleaned_data['url']
        content = self.cleaned_data['content']
        tags = self.cleaned_data['tags']
        secret = self.cleaned_data['secret']

        model = ReadFeed(title=title,
                         url=url,
                         content=content,
                         tags=tags,
                         secret=secret,
                         creater=user)
        model.save()
        return model
