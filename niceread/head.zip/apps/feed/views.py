# -*- coding: utf-8 -*-

from django.http import HttpResponseRedirect, Http404, HttpResponseForbidden, HttpResponse
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from django.core.urlresolvers import reverse

from django.contrib.auth.models import User
from feed.models import ReadFeed, Share, Star
from feed.forms import ReadFeedForm

def feed_all(request):
    feed_list = ReadFeed.objects.all()

    return render_to_response('feed/index.html',
                              {'feed_list': feed_list},
                              context_instance=RequestContext(request))

def feed_detail(request, feed_pk):
    feed = get_object_or_404(ReadFeed, pk=feed_pk)

    return render_to_response('feed/feed_detail.html',
                              {'feed': feed},
                              context_instance=RequestContext(request))
@login_required
def feed_create(request):
    if request.method == "POST":
        form = ReadFeedForm(request.POST)
        if form.is_valid():
            feed = form.save(request.user)
            return HttpResponseRedirect(feed.get_absolute_url())
    else:
        form = ReadFeedForm()

    return render_to_response('feed/feed_create.html',
                              {'form': form},
                              context_instance=RequestContext(request))

@login_required
def share(request, feed_pk):
    feed = get_object_or_404(ReadFeed, pk=feed_pk)

    sh, create = Share.objects.get_or_create(feed=feed, user=request.user)
    if create:
        sh.save()

    #return HttpResponseRedirect(sh.feed.get_absolute_url())
    return HttpResponseRedirect(request.META['HTTP_REFERER'])

@login_required
def star(request, feed_pk):
    feed = get_object_or_404(ReadFeed, pk=feed_pk)

    st, create = Star.objects.get_or_create(feed=feed, user=request.user)
    if create:
        st.save()

    #return HttpResponseRedirect(sh.feed.get_absolute_url())
    return HttpResponseRedirect(request.META['HTTP_REFERER'])
