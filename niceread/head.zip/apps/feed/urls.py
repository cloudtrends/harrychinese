from django.conf.urls.defaults import *
from django.views.generic import TemplateView

urlpatterns = patterns('',
                       url(r'^$', 'feed.views.feed_all', name="feed_all"),
                       url(r'^feed/(?P<feed_pk>\d+)/$', 'feed.views.feed_detail', name='feed_detail'),
                       url(r'^create/$', 'feed.views.feed_create'),
                       url(r'^share/(?P<feed_pk>\d+)/$', 'feed.views.share', name='feed_sh'),
                       url(r'^star/(?P<feed_pk>\d+)/$', 'feed.views.star', name='feed_st'),


)
