from django.shortcuts import render_to_response
from django.template import RequestContext
from django.http import HttpResponseRedirect
from django.conf import settings
from django.core.urlresolvers import reverse

from  douban.client import OAuthClient

def login(request):
    return render_to_response('demo/login.html', context_instance=RequestContext(request))

def douban_login(request):
    client = OAuthClient(key=settings.DOUBAN_APP_KEY, secret=settings.DOUBAN_APP_SECRET)
    key, secret = client.get_request_token()
    if not key:
        pass

    signin_url = client.get_authorization_url(key, secret)
    #request.session['request_token'] = client.
    return HttpResponseRedirect(signin_url)
