from django.conf.urls.defaults import *
from django.views.generic import TemplateView

urlpatterns = patterns('',
                       url(r'^$', TemplateView.as_view(template_name='demo/index.html')),
                       url(r'^login/$', TemplateView.as_view(template_name='demo/login.html')),
                       url(r'^login/douban/$', 'demo.views.douban_login', name='douban_login'),

)
