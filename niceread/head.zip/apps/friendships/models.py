# -*- coding: utf-8 -*-

import datetime
from django.core.mail import send_mail
from django.template.loader import get_template
from django.template import Context
from django.conf import settings

from django.db import models
from django.contrib.auth.models import User

class Friendship(models.Model):
    from_friend = models.ForeignKey(User, related_name='friend_set')
    to_friend = models.ForeignKey(User, related_name='to_friend_set')
    added = models.DateField(default=datetime.date.today)

    def __unicode__(self):
        return '%s, %s' % (self.from_friend.username, self.to_friend.username)

    class Meta:
        unique_together = (('to_friend', 'from_friend'), )

    @models.permalink
    def get_absolute_url(self):
        return ('fri_to', (), {
            'username': self.to_friend.username
            })

class Invitation(models.Model):
    email = models.EmailField()
    code = models.CharField(max_length=20)
    sender = models.ForeignKey(User)

    def __unicode__(self):
        return '%s, %s' % (self.sender.username, self.email)

    def send(self):
        subject = '你的朋友邀请你加入笔记本网站'
        link = 'http://%s/accept/%s/' %  (settings.SITE_HOST, self.code)
        template = get_template('friendships/invitation_email.txt')
        context = Context({
            'link': link,
            'sender': self.sender.username
            })

        message = template.render(context)
        send_mail(subject,
                  message,
                  settings.DEFAULT_FROM_EMAIL,
                  [self.email,]
                  )
