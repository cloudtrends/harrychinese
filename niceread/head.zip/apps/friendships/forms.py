# -*- coding: utf-8 -*-

from django import forms

class FriendInviteForm(forms.Form):
    email = forms.EmailField(label="Ta的电子信邮箱")

