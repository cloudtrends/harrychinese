from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('',
                       url(r'^people/(?P<username>\w+)/friends/$', 'friendships.views.friends_page', name="fri_to"),
                       url(r'^people/(?P<username>\w+)/friends/add/$', 'friendships.views.friend_add'),
                       url(r'^people/(?P<username>\w+)/friends/unfollow/$', 'friendships.views.unfollow'),
                       url(r'^invite/$', 'friendships.views.friend_invite'),
                       url(r'^accept/(\w+)/$', 'friendships.views.friend_accept'),
                       )
