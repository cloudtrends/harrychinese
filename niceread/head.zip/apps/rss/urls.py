from django.conf.urls.defaults import patterns, include, url
from rss.views import ReadRSS, SelfRSS, PubRSS

## feeds = {
##     'rss': NoteFeed
##     }

urlpatterns = patterns('',
                       ## url(r'^people/(?P<username>\w+)/note/rss/$',
                       ##     'django.contrib.syndication.views.feed',
                       ##     {'feed_dict': feeds}
                       ##     ),
                       url(r'^people/(?P<username>\w+)/pub/rss/$', PubRSS(), name='pub_rss'),
                       url(r'^people/(?P<username>\w+)/self/rss/$', SelfRSS(), name='self_rss'),
)
