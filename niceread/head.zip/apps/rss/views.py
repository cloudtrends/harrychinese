# -*- coding: utf-8 -*-

from django.conf import settings
from django.contrib.sites.models import Site
from django.contrib.syndication.views import Feed
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404

from feed.models import ReadFeed

class ReadRSS(Feed):
    title_template = 'rss/readfeed_title.html'
    description_template = 'rss/user_rss_description.html'

    def get_object(self, request, username):
        user = get_object_or_404(User, username=username)
        return user #get_object_or_404(Note, author=user)

    def title(self, obj):
        '''订阅RSS标题'''
        return u"来自于 %s 的记录" % obj.username

    def link(self, obj):
        '''RSS的源访问地址'''

        return "http://%s/people/%s/" % (Site.objects.get_current().domain,
                                  obj.username)

    def description(self, obj):
        '''关于RSS的订阅说明'''
        return u"以下内容来自于： %s." % obj.username

    ## def items(self, obj):
    ##     return ReadFeed.objects.filter(creater=obj, secret=self.secret).order_by('-pub_date')[:10]

    def item_pubdate(self, item):
        return item.pub_date

    def item_author_name(self, item):
        '''创建者'''
        return item.creater.username

    def item_author_link(self, item):
        return 'http://%s/people/%s/' % (Site.objects.get_current().domain,
                                         item.creater.username)

class SelfRSS(ReadRSS):
    """
    TODO: 功能仍然不完全
    拥用者全部RSS"""
    def items(self, obj):
        return ReadFeed.objects.filter(creater=obj).order_by('-pub_date')[:10]

class PubRSS(ReadRSS):
    """访问者公开RSS"""

    def items(self, obj):
        return ReadFeed.objects.filter(creater=obj, secret=False).order_by('-pub_date')[:10]
