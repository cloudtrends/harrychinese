from django.db import models

class SouthTut(models.Model):
    name = models.CharField(max_length=100)
    title = models.CharField(max_length=255)
    updated = models.DateTimeField()

