# -*- coding: utf-8 -*-

from django.conf.urls.defaults import *

urlpatterns = patterns('',
                       ## note的所有tags
                       url(r'^feed/tags/$', 'tags.views.feed_tag_all', name='f_t_a'),
                       ## 标有当前Tag的所有note条目
                       url(r'^feed/tag/(?P<tag>[^/]+)/$', 'tags.views.get_feed', name='get_feed'),
                       ## 当前用户的所有tag
                       url(r'^people/(?P<username>\w+)/feed/tags/$', 'tags.views.get_feed_all', name='u_feed_tags'),
                       ## 当前用户当前Tagr所有的note条目
                       url(r'^people/(?P<username>\w+)/feed/tag/(?P<tag>[^/]+)/$', 'tags.views.get_user_feed_tag', name='u_feed_tag'),

)
