#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django.conf import settings
from django.http import HttpResponseRedirect, Http404, HttpResponseForbidden
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from django.core.urlresolvers import reverse

from django.contrib.auth.models import User
from tagging.models import Tag, TaggedItem
from tagging.utils import calculate_cloud, LOGARITHMIC

from feed.models import ReadFeed

@login_required
def get_feed(request, tag):
    """针对全站具有相同tag的note显示"""

    tag_object = get_object_or_404(Tag, name=tag)
    ## note_list = TaggedItem.objects.get_by_model(Note, tag_object)
    notes = TaggedItem.objects.get_by_model(ReadFeed, tag_object)
    ## 保护用户秘密笔记
    ## 功能是有了，但仍觉得不怎么优雅, 检索出来的结果在时间排序上也有问题
    feed_list = [note for note in notes if (note.creater==request.user) or \
                 (note.creater != request.user and not note.secret) ]  ## 自己的全部
    ##others_list = [note for note in notes if note.author !=request.user and not note.secret] ## 不是自己的且非秘密的
    ##note_list = my_list + others_list  ## 两部份全起来

    var = RequestContext(request, {'feed_list': feed_list,
                                   'tag':tag,
                                   'c_user': request.user})

    return render_to_response('tags/feed_all_by_tag.html', var)

@login_required
def feed_tag_all(request):
    """显示所有note的tag"""

    clouds = Tag.objects.cloud_for_model(ReadFeed,
                                            steps=settings.TAG_LIST_LEVEL,
                                            distribution=LOGARITHMIC,
                                            filters=None,
                                            min_count=None)
    var = RequestContext(request, {'clouds': clouds,
                                   'c_user': request.user,
                                   })
    return render_to_response('tags/feed_tag_all.html', var)


@login_required
def get_feed_all(request, username):
    """对单个用户的全部tag显示"""
    c_user = get_object_or_404(User, username=username)

    tags = Tag.objects.usage_for_model(ReadFeed,
                                       counts=True,
                                       filters=dict(creater__username=username))

    clouds = calculate_cloud(tags, steps=settings.TAG_LIST_LEVEL, distribution=LOGARITHMIC)

    var = RequestContext(request, {'tags': tags,
                                   'c_user': c_user,
                                   'clouds': clouds
                                   })

    return render_to_response('tags/feed_tags_c.html', var)

@login_required
def get_user_feed_tag(request, username, tag):
    """针对用户Tag，搜索相应的note"""

    tag_object = get_object_or_404(Tag, name=tag)

    notes = TaggedItem.objects.get_by_model(ReadFeed, tag_object)

    author = User.objects.get(username=username)

    if author == request.user:
        ## 保护用户秘密笔记
        note_list = [note for note in notes if note.creater==author]
    else:
        note_list = [note for note in notes if note.creater==author and not note.secret]

    var = RequestContext(request, {'feed_list':note_list,
                                   'tag': tag,
                                   'c_user': author,
                                   'is_user': True})

    return render_to_response('tags/feed_all_by_tag.html', var)

