--------------------------------------------------------
--Create tables and package for UnitTesting
--------------------------------------------------------
set echo on

spool &&Oracle_ServiceName.Install.txt

PROMPT Starting install at:;
SELECT TO_CHAR(SYSDATE, 'DD-MON-YY HH24:MI:SS') FROM dual;

PROMPT Connecting;
connect &&oracle_user/&&oracle_password@&&Oracle_ServiceName ;

PROMPT Begin Execute script Create_Tables.sql;
@Create_Tables.sql


PROMPT Begin Execute script Insert_Data.sql;
@Insert_Data.sql


PROMPT Begin Execute script Create_Packages.sql;
@Create_packages.sql

PROMPT Completing install at:;
SELECT TO_CHAR(SYSDATE, 'DD-MON-YY HH24:MI:SS') FROM dual;
spool off
--------------------------------------------------------