Steps
1. Create one db namely Test1_Demo_Db
2. Run sql_script.sql to create the fun_add_values(), and its other helper db objects, separately T_FUN_ADD_VALUES_HELPER and fun_add_values_helper()
3. Modify the db1 connection string in TestCase_Demo1.xml, especially Sql Server instance and user/pwd suitable for your situation
4. Save excel_testpoints_ref.xls in c:\ root folder
5. Load and run TestCase_Demo1.xml by using AnyDbTest. 
