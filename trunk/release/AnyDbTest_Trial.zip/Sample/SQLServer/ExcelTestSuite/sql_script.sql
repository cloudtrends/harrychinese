USE [Test1_Demo_Db]
GO
/****** Object:  Table [dbo].[T_FUN_ADD_VALUES_HELPER]    Script Date: 02/05/2010 18:05:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[T_FUN_ADD_VALUES_HELPER]
    (
      [F_X] [int] NULL ,
      [F_Y] [int] NULL ,
      [F_Expected_Result] [int] NULL
    )
ON  [PRIMARY]


go


 
/****** Object:  UserDefinedFunction [dbo].[fun_add_values]    Script Date: 02/05/2010 18:03:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		AnyDbTest
-- Description:	Add two number, 
--              this function will need to unit test to verify 
-- =============================================
CREATE FUNCTION [dbo].[fun_add_values] ( @x INT, @y INT )
RETURNS INT
AS 
    BEGIN
	-- Declare the return variable here
        DECLARE @Result INT

	-- Add the T-SQL statements to compute the return value here
        SELECT  @Result = @x + @y ;

	-- Return the result of the function
        RETURN @Result

    END


GO
/****** Object:  UserDefinedFunction [dbo].[fun_add_values_helper]    Script Date: 02/05/2010 18:05:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		AnyDbTest
-- Create date: 
-- Description:	return o if success, else return 1
--              this funtion is a helper function to verfiy fun_add_values
-- =============================================
CREATE FUNCTION [dbo].[fun_add_values_helper] ( )
RETURNS INT
AS 
    BEGIN
	-- Declare the return variable here
        DECLARE @Result INT ;
        SET @Result = 0 ;
        DECLARE @Expected INT ,
            @Actual INT ;
        DECLARE @x INT ,
            @y INT ;

        DECLARE Test1_Cursor CURSOR FOR
        SELECT F_X, F_Y, F_Expected_Result FROM T_FUN_ADD_VALUES_HELPER ;

        OPEN Test1_Cursor ;
        FETCH NEXT FROM Test1_Cursor INTO @x, @y, @Expected ;
  

        WHILE @@FETCH_STATUS = 0 
            BEGIN 
                SET @Actual = dbo.fun_add_values(@x, @y) ;
                IF @Expected <> @Actual 
                    BEGIN
                        SET @Result = 1 ;
                        BREAK ;
                    END ;
                FETCH NEXT FROM Test1_Cursor INTO @x, @y, @Expected ;
            END ;
        CLOSE Test1_Cursor ;
        DEALLOCATE Test1_Cursor ;
 
    
	-- Return the result of the function
        RETURN @Result

    END




