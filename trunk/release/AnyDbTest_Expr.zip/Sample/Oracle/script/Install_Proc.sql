--------------------------------------------------------
--Create package for UnitTesting
--------------------------------------------------------
set echo on

spool &&Oracle_ServiceName.Install.txt

PROMPT Starting install at:;
SELECT TO_CHAR(SYSDATE, 'DD-MON-YY HH24:MI:SS') FROM dual;

PROMPT Connecting;
connect HR/&&HR_user_password@&&Oracle_ServiceName ;
 

PROMPT Begin Execute script Create_packages.sql;
@Create_packages.sql

PROMPT Completing install at:;
SELECT TO_CHAR(SYSDATE, 'DD-MON-YY HH24:MI:SS') FROM dual;
spool off
--------------------------------------------------------