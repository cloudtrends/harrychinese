--======================================
-- insert 4 rows into regions table
--======================================
Insert into REGIONS (REGION_ID,REGION_NAME) VALUES (1,'Europe');
Insert into REGIONS (REGION_ID,REGION_NAME) VALUES (2,'Americas');
Insert into REGIONS (REGION_ID,REGION_NAME) VALUES (3,'Asia');
Insert into REGIONS (REGION_ID,REGION_NAME) VALUES (4,'Middle East and Africa');


--===============================================
-- insert 25 rows into countries table
--===============================================
insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('AR', 'Argentina', 2);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('AU', 'Australia', 3);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('BE', 'Belgium', 1);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('BR', 'Brazil', 2);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('CA', 'Canada', 2);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('CH', 'Switzerland', 1);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('CN', 'China', 3);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('DE', 'Germany', 1);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('DK', 'Denmark', 1);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('EG', 'Egypt', 4);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('FR', 'France', 1);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('HK', 'HongKong', 3);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('IL', 'Israel', 4);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('IN', 'India', 3);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('IT', 'Italy', 1);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('JP', 'Japan', 3);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('KW', 'Kuwait', 4);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('MX', 'Mexico', 2);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('NG', 'Nigeria', 4);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('NL', 'Netherlands', 1);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('SG', 'Singapore', 3);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('UK', 'United Kingdom', 1);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('US', 'United States of America', 2);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('ZM', 'Zambia', 4);

insert into countries (COUNTRY_ID, COUNTRY_NAME, REGION_ID)
values ('ZW', 'Zimbabwe', 4);



--=====================================================
-- insert 23 rows into locations table
--=====================================================
 insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (1000, '1297 Via Cola di Rie', '00989', 'Roma', '', 'IT');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (1100, '93091 Calle della Testa', '10934', 'Venice', '', 'IT');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (1200, '2017 Shinjuku-ku', '1689', 'Tokyo', 'Tokyo Prefecture', 'JP');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (1300, '9450 Kamiya-cho', '6823', 'Hiroshima', '', 'JP');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (1400, '2014 Jabberwocky Rd', '26192', 'Southlake', 'Texas', 'US');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (1500, '2011 Interiors Blvd', '99236', 'South San Francisco', 'California', 'US');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (1600, '2007 Zagora St', '50090', 'South Brunswick', 'New Jersey', 'US');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (1700, '2004 Charade Rd', '98199', 'Seattle', 'Washington', 'US');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (1800, '147 Spadina Ave', 'M5V 2L7', 'Toronto', 'Ontario', 'CA');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (1900, '6092 Boxwood St', 'YSW 9T2', 'Whitehorse', 'Yukon', 'CA');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (2000, '40-5-12 Laogianggen', '190518', 'Beijing', '', 'CN');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (2100, '1298 Vileparle (E)', '490231', 'Bombay', 'Maharashtra', 'IN');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (2200, '12-98 Victoria Street', '2901', 'Sydney', 'New South Wales', 'AU');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (2300, '198 Clementi North', '540198', 'Singapore', '', 'SG');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (2400, '8204 Arthur St', '', 'London', '', 'UK');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (2500, 'Magdalen Centre, The Oxford Science Park', 'OX9 9ZB', 'Oxford', 'Oxford', 'UK');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (2600, '9702 Chester Road', '09629850293', 'Stretford', 'Manchester', 'UK');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (2700, 'Schwanthalerstr. 7031', '80925', 'Munich', 'Bavaria', 'DE');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (2800, 'Rua Frei Caneca 1360 ', '01307-002', 'Sao Paulo', 'Sao Paulo', 'BR');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (2900, '20 Rue des Corps-Saints', '1730', 'Geneva', 'Geneve', 'CH');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (3000, 'Murtenstrasse 921', '3095', 'Bern', 'BE', 'CH');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (3100, 'Pieter Breughelstraat 837', '3029SK', 'Utrecht', 'Utrecht', 'NL');

insert into locations (LOCATION_ID, STREET_ADDRESS, POSTAL_CODE, CITY, STATE_PROVINCE, COUNTRY_ID)
values (3200, 'Mariano Escobedo 9991', '11932', 'Mexico City', 'Distrito Federal,', 'MX');

