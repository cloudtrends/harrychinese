#coding:utf-8

from flaskext.sqlalchemy import SQLAlchemy
#from flaskext.script import Manager

db = SQLAlchemy()
#manager = Manager()
