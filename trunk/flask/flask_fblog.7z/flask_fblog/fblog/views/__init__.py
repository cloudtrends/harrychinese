from fblog.views.blog import blog
from fblog.views.admin import admin
from fblog.views.account import account, login_manager
from fblog.views.feeds import feed
